package com.example.Produtos.controller;


import com.example.Produtos.model.Cliente;
import com.example.Produtos.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@RequestMapping("/apiCliente")
public class ClienteController {

    @Autowired
    ClienteRepository clRep;

    @GetMapping("/todos")
    private List<Cliente> buscartodos()
    {
        return clRep.findAll();
    }
}
