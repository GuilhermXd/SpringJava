package com.example.Produtos.repository;

import com.example.Produtos.model.Cliente;
import com.example.Produtos.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteRepository extends JpaRepository<Cliente, Integer> {
}
